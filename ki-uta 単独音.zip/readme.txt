Thank you for downloading ki-uta ! A high school project by Haj-P and kiyeo

NOTE: Please see user agreement before use of this voicebank.

VERSION HISTORY
Version 1.0
Standard Japanese CV voicebank

PROFILE
Name: ki-uta
Gender: Female
Language: Japanese
Voiced by: kiyeo

!! If you choose to modify the voicebank, please do not edit or remove anything below this line !!

USER AGREEMENT:
This voicebank and its associated character are free and open for usage and modification in any non-commercial or commercial content with the following restrictions:
 - Do not use the voicebank in any political or religious content.
 - Do not use the voicebank with the intent of harming or harrassing any group or individual. 
 - Do not use the voicebank for any discriminatory or offensive content towards any ethnicity, religion, sex, sexuality, etc.
 - Do not use the voicebank for any explicit sexual content.
 - Do not use the voicebank to advertise any commercial product or service. Commercial use is limited to monetization of the content produced.
 - Do not use the voicebank in any illegal or unlawful activity that would put the voicebank or the authors in any legal liability.
Attribution:
Attribution to the voicebank (ki-uta) and/or the author (Haj-P and kiyeo) is expected in any published media using the voicebank or its associated character.
Disclaimer:
We(Haj-P and kiyeo) hold no responsibility to any incidents, damage, or loss by the user from downloading or using the voicebank or character.
We hold no responsibility to any incidents, damage, or loss that occurs to any third party as a result of usage of the voicebank or character.

If you have any questions, please contact the voicebank author: leonidas98735698@gmail.com

Copyright Haj-P 2024